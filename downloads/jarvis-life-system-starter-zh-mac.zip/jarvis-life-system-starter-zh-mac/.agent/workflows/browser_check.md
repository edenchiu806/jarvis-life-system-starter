# /browser_check

使用 browser-operator 打開網頁、檢查頁面並驗證連結。
