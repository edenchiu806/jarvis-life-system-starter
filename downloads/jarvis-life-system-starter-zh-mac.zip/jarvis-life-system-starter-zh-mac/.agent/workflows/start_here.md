# /start_here

啟動 onboarding，開始完成設定，並帶使用者進入體驗與設置的指引任務。
