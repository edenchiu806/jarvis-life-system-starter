# /system_health

檢查核心資料夾、Skill、Agent、記憶骨架與下載檔是否存在。
