---
name: browser-operator
description: 使用可用的瀏覽器、in-app browser 或 computer use 工具打開網站、檢查頁面、驗證下載、讀取畫面、點擊流程或測試表單。當任務需要 open browser / inspect page / 網頁操作 / 截圖 / 驗證頁面時使用。
---

# Browser Operator

1. 先說明要打開哪個頁面與驗證什麼。
2. 使用可用瀏覽器工具打開頁面。
3. 檢查主要文字、按鈕、下載連結、行動版可讀性與錯誤狀態。
4. 不輸入敏感資料，除非使用者明確要求且風險已說明。
5. 若沒有瀏覽器工具，提供手動驗證清單。
