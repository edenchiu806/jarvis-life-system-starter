---
name: project-intake
description: 把模糊想法轉成可執行專案，包括目標、限制、第一個里程碑、風險、需要的 Agent/Skill/Workflow 與下一步。當使用者有新想法、新專案或混亂任務時使用。
---

# Project Intake

1. 用一句話重述目標。
2. 定義第一個可見成果。
3. 列出限制、未知與風險。
4. 推薦需要的 Agent、Skill 與 Workflow。
5. 建立第一個 session-state。
