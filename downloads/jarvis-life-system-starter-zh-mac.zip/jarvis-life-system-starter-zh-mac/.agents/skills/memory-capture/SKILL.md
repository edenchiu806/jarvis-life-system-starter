---
name: memory-capture
description: 保存任務狀態、個人偏好、決策、下一步與 handoff，讓 Jarvis 下次可以接續。當使用者要求記住、保存進度、下次接續、結束工作階段或建立記憶時使用。
---

# Memory Capture

保存前先判斷資訊應放在 `session-state`、`handoff` 還是 `user` 偏好。私人資料只保存摘要與必要欄位，並取得同意。
