---
name: daily-review
description: 做每日收束，整理今天進展、卡點、決策、明日第一步，以及可沉澱成 Skill 或 Workflow 的重複模式。當使用者要回顧今天、收尾或準備明天時使用。
---

# Daily Review

問五件事：今天推進了什麼、卡在哪裡、做了什麼決策、明天第一步、是否有值得做成 Skill 的重複模式。
