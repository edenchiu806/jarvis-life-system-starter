---
name: agent-skill-builder
description: 將使用者的重複任務、角色需求、工作方法或 Skool/Skill 想法轉成 Jarvis Agent、Codex Skill 或 Workflow。當使用者想建立 Agent、Skill、工作流、助理角色、任務模板或自動化能力時使用。
---

# Agent / Skill Builder

1. 先釐清這個能力要解決什麼重複問題。
2. 判斷要做 Agent、Skill 或 Workflow。
3. 使用 `references/requirements-template.md` 產出需求。
4. 依需要建立 `system/agents/*.yaml`、`.agents/skills/*/SKILL.md` 或 `.agent/workflows/*.md`。
5. 建立後用一個真實情境測試。

若使用者說 Skool，先判斷他指的是 Codex Skill，還是 Skool 社群平台。
