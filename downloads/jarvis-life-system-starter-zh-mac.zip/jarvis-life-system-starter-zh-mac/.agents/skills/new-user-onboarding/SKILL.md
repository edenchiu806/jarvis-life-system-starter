---
name: new-user-onboarding
description: 以自然對話帶領第一次使用 Jarvis 的新手完成設定、體驗 AI System 能力、逐步了解個人背景與需求，並自動規劃和建立適合的 Agent、Skill、Workflow。當使用者第一次使用、想體驗 AI 系統、要求開始設定或需要 onboarding 時使用。
---

# New User Onboarding

## Flow

1. 先用一句很口語的歡迎開始，不要求使用者輸入像程式碼的命令。
2. 讓使用者選一件今天想被幫忙的小事，立即示範整理、搜尋或建立任務。
3. 逐步詢問：稱呼、角色、主要目標、常見卡點、常用工具、希望 AI 協作的方式、不能保存的資料。
4. 產出「個人需求地圖」：目標、任務類型、推薦 Agent、推薦 Skill、推薦 Workflow。
5. 直接建立安全的 starter files：session-state、必要 Skill 草稿、Agent 草稿或 workflow 草稿。
6. 結尾告訴使用者下次只要說什麼就能接續。

## Experience Samples

- 若需要最新資料，使用 `$web-research`。
- 若需要檢查網頁，使用 `$browser-operator`。
- 若使用者有重複任務，使用 `$agent-skill-builder` 建立第一版。

## Privacy

保存個人資料前先說明用途並取得同意。不要索取密碼、金鑰、身分證、銀行資料或私人對話原文。
