# Mac

Mac 版：解壓縮後用 Codex App 的 Cmd + O 選擇資料夾。

```text
嗨 Jarvis，請帶我完成第一次設定，順便讓我體驗你可以怎麼幫我。
```
