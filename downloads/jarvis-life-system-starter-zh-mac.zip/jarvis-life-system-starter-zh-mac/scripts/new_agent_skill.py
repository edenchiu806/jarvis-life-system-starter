#!/usr/bin/env python3
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def normalize(value: str, sep: str) -> str:
    chars = []
    for char in value.lower().strip():
        if char.isalnum():
            chars.append(char)
        elif char in " _-":
            chars.append(sep)
    output = "".join(chars)
    while sep + sep in output:
        output = output.replace(sep + sep, sep)
    return output.strip(sep)

parser = argparse.ArgumentParser()
parser.add_argument("--name", required=True)
parser.add_argument("--kind", choices=["skill", "agent", "workflow"], default="skill")
args = parser.parse_args()

if args.kind == "skill":
    slug = normalize(args.name, "-")
    path = ROOT / ".agents" / "skills" / slug / "SKILL.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise SystemExit(f"Already exists: {path}")
    path.write_text(f"---\nname: {slug}\ndescription: TODO: 描述什麼時候要使用這個 skill。\n---\n\n# {args.name}\n\n## 工作流程\n\n1. TODO\n", encoding="utf-8")
elif args.kind == "agent":
    slug = normalize(args.name, "_")
    path = ROOT / "system" / "agents" / f"{slug}.yaml"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise SystemExit(f"Already exists: {path}")
    path.write_text(f"id: {slug}\nname: {args.name.replace(' ', '')}\ndisplay_name: {args.name}\ndescription: TODO: 描述這個 Agent 負責什麼，以及什麼時候使用。\nskills: []\n", encoding="utf-8")
else:
    slug = normalize(args.name, "_")
    path = ROOT / ".agent" / "workflows" / f"{slug}.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise SystemExit(f"Already exists: {path}")
    path.write_text(f"# /{slug}\n\nTODO: 描述這個 workflow 的觸發時機、步驟與完成標準。\n", encoding="utf-8")
print(path)
