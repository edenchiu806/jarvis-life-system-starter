# Codex 設定說明

在 Codex App 中打開這個資料夾，並使用 Local mode，讓 Codex 可以讀寫這個工作區。

## 第一句話

```text
嗨 Jarvis，請帶我完成第一次設定，順便讓我體驗你可以怎麼幫我。
```

Codex 會掃描 `.agents/skills`。這個 starter 內建：

- `$new-user-onboarding`
- `$web-research`
- `$browser-operator`
- `$agent-skill-builder`
- `$memory-capture`
- `$project-intake`
- `$daily-review`

如果 Skill 沒有出現，請重新啟動 Codex 或重新打開資料夾。
