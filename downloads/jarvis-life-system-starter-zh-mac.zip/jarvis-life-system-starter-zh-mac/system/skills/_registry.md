# Starter Skills 索引

- new-user-onboarding：新手導覽與個人化設定
- web-research：網路搜尋與來源整理
- browser-operator：瀏覽器打開、檢查與驗證
- agent-skill-builder：製作 Agent、Skill 與 Workflow
- memory-capture：任務記憶與 handoff
- project-intake：新專案 intake
- daily-review：每日回顧與收束
