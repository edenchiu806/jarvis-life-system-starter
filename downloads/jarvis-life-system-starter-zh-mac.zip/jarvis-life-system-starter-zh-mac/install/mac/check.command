#!/usr/bin/env bash
cd "$(dirname "$0")/../.."
python3 scripts/starter_health_check.py
read -r -p "按 Enter 關閉..."
