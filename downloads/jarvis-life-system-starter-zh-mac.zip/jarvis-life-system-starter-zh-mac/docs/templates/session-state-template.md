---
id: "{{task-id}}"
status: "active"
priority: "P2"
last_updated: "{{date}}"
goal: "{{one-sentence-goal}}"
---

# {{task-title}}

## 目前狀態

## 已做決策

## 下一步

## 接續提示
