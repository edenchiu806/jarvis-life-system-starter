# Harness 規範

## Task Start Gate

- 目標是什麼？
- 成功標準是什麼？
- 需要最新資料或瀏覽器嗎？
- 有沒有隱私、金錢、帳號或公開發布風險？

## Proof Contract

完成前提供至少一種證據：檔案路徑、檢查結果、來源連結、頁面驗證或 handoff。
