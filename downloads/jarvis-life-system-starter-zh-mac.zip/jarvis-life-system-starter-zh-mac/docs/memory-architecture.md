# 記憶架構

| 路徑 | 用途 |
|---|---|
| `vault/_memory/active-threads.json` | 進行中任務索引 |
| `vault/_memory/session-state/` | 可接續任務的真相來源 |
| `vault/_memory/handoffs/` | 壓縮後的重啟筆記 |
| `vault/_memory/context-window.json` | 全域焦點儀表板 |
| `vault/_memory/user/` | 經同意後保存的使用者偏好 |
