# Starter Skills Registry

| Skill | 用途 | Codex path |
|---|---|---|
| new-user-onboarding | 第一次使用 Jarvis 的導覽 | `.agents/skills/new-user-onboarding` |
| agent-skill-builder | 建立 Agent / Skill / Workflow | `.agents/skills/agent-skill-builder` |
| memory-capture | 保存任務狀態與 handoff | `.agents/skills/memory-capture` |
| project-intake | 把模糊想法變成可執行任務 | `.agents/skills/project-intake` |
| daily-review | 每日回顧與明日第一步 | `.agents/skills/daily-review` |
