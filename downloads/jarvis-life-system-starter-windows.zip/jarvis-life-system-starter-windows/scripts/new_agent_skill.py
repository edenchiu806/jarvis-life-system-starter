#!/usr/bin/env python3
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def normalize(value: str, sep: str) -> str:
    allowed = []
    for char in value.lower().strip():
        if char.isalnum():
            allowed.append(char)
        elif char in " _-":
            allowed.append(sep)
    output = "".join(allowed)
    while sep + sep in output:
        output = output.replace(sep + sep, sep)
    return output.strip(sep)

parser = argparse.ArgumentParser()
parser.add_argument("--name", required=True, help="Human-readable capability name")
parser.add_argument("--kind", choices=["skill", "agent"], default="skill")
args = parser.parse_args()

if args.kind == "skill":
    slug = normalize(args.name, "-")
    path = ROOT / ".agents" / "skills" / slug / "SKILL.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise SystemExit(f"Already exists: {path}")
    path.write_text(
        f"---\nname: {slug}\ndescription: TODO: Describe when to use this skill.\n---\n\n"
        f"# {args.name}\n\n## Workflow\n\n1. TODO\n\n## Done Means\n\n- TODO\n",
        encoding="utf-8",
    )
    print(path)
else:
    slug = normalize(args.name, "_")
    path = ROOT / "system" / "agents" / f"{slug}.yaml"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise SystemExit(f"Already exists: {path}")
    path.write_text(
        f"id: {slug}\nname: {args.name.replace(' ', '')}\ndisplay_name: {args.name}\n"
        "description: TODO: Describe what this agent owns.\nskills: []\n",
        encoding="utf-8",
    )
    print(path)
