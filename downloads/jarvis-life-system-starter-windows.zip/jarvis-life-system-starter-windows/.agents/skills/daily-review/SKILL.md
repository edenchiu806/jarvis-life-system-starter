---
name: daily-review
description: Run a short end-of-day review that captures progress, blockers, decisions, tomorrow's first action, and reusable lessons. Use when the user wants to close the day, summarize work, or prepare tomorrow.
---

# Daily Review

Ask only what is needed:

1. What moved forward today?
2. What got stuck?
3. What decision should be preserved?
4. What is tomorrow's first action?
5. Is there a reusable lesson that should become a Skill or checklist?
