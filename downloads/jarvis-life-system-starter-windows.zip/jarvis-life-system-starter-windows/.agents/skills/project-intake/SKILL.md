---
name: project-intake
description: Turn a vague idea into a concrete Jarvis project brief with goal, constraints, first milestone, risks, and next actions. Use when the user has a new project, messy idea, or unclear task.
---

# Project Intake

1. Restate the goal in one sentence.
2. Identify the first useful outcome.
3. List constraints, unknowns, and risks.
4. Create next actions that can be done in under one hour.
5. Recommend whether this needs a session-state file.
