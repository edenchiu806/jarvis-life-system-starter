# Acceptance Checklist

- [ ] The name is short and specific.
- [ ] Trigger examples are clear.
- [ ] Non-trigger cases are listed.
- [ ] Private examples are removed.
- [ ] The first version can be tested in one realistic task.
- [ ] The output has a clear done condition.
