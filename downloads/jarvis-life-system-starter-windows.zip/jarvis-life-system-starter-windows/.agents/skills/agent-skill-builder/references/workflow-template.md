# Workflow Name

## Trigger

Use this workflow when:

## Phases

1. Intake
2. Draft
3. Execute
4. Verify
5. Handoff

## Done Means

- 
