---
name: your-skill-name
description: State exactly what this skill does and when Codex should use it.
---

# Your Skill Name

## Workflow

1. 
2. 
3. 

## Output

- 

## Guardrails

- 
