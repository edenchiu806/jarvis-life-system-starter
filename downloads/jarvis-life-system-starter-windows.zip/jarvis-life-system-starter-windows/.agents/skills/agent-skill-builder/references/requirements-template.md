# Agent / Skill Requirements

## Name

## User Problem

## Trigger Examples

- User says:
- User says:

## Should Not Trigger When

- 

## Inputs Needed

- 

## Expected Output

- 

## Validation

- 
