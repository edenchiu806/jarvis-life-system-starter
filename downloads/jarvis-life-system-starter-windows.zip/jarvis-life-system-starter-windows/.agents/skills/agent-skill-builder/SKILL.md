---
name: agent-skill-builder
description: Build or improve a Jarvis Agent, Codex Skill, or repeatable workflow from a user's recurring task. Use when the user asks to create an Agent, Skill, Skool-like capability module, reusable prompt, workflow, assistant role, or automation playbook.
---

# Agent / Skill Builder

Use this skill to turn repeated work into a reusable capability.

## Workflow

1. Identify the job: what should the Agent or Skill help with?
2. Choose the artifact:
   - Agent: use when a role needs ownership, judgment, or routing.
   - Skill: use when Codex needs reusable procedural instructions.
   - Workflow: use when the task has a fixed phase sequence.
3. Draft requirements with `references/requirements-template.md`.
4. Draft the artifact from:
   - `references/agent-template.yaml`
   - `references/skill-template.md`
   - `references/workflow-template.md`
5. Add acceptance checks from `references/acceptance-checklist.md`.
6. Keep the first version small and test it on one realistic task.

## Rules

- Prefer one focused Skill over a broad toolbox.
- Put trigger conditions in Skill frontmatter `description`.
- Keep private examples out of reusable instructions.
- Add scripts only when repeatability matters.
- If the user says "Skool", clarify whether they mean Codex Skill or the Skool community platform.
