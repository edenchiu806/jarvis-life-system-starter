---
name: memory-capture
description: Capture durable task state, decisions, next actions, and handoff notes into the Jarvis vault. Use when a task should be resumed later, when the user asks to remember project progress, or when ending a long work session.
---

# Memory Capture

1. Decide whether the information belongs in `session-state`, `handoff`, or user preferences.
2. Save only what is needed to resume work.
3. Avoid copying sensitive raw content when a short abstract summary is enough.
4. Include current state, decisions, next actions, and a resume prompt.
