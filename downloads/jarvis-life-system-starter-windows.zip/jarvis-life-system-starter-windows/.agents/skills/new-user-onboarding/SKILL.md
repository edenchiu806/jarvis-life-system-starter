---
name: new-user-onboarding
description: Guide a first-time, non-technical user through Jarvis setup, folder orientation, first task creation, and safe next steps. Use when the user is new to AI, asks how to start using Jarvis, or needs a beginner-friendly walkthrough after opening the starter kit in Codex.
---

# New User Onboarding

1. Welcome the user and explain that Jarvis works by reading this local folder.
2. Ask for one concrete thing they want help with today.
3. Create or update a session-state file from `docs/templates/session-state-template.md`.
4. Explain the four important locations: `AGENTS.md`, `.agents/skills`, `docs`, and `vault/_memory`.
5. End with one next action the user can do immediately.

Keep the tone simple. Avoid AI jargon unless the user asks.
Never request passwords, API keys, government IDs, or private financial data during onboarding.
