# Codex 使用補充

這個 starter kit 是為 Codex App / CLI 可以直接讀取的本地資料夾設計。

## 建議入口

1. 用 Codex App 開啟這個資料夾。
2. 確認模式是 Local，讓 Codex 能讀寫這個工作區。
3. 第一則訊息使用：

```text
我是第一次使用 Jarvis，請用 $new-user-onboarding 帶我完成設定，並幫我建立第一個任務。
```

## Skill 位置

Codex 會掃描 `.agents/skills`。本包已預先放入：

- `$new-user-onboarding`
- `$agent-skill-builder`
- `$memory-capture`
- `$project-intake`
- `$daily-review`

若 Codex 沒看到 Skill，請重新啟動 Codex 或重新開啟資料夾。
