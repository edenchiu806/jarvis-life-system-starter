# Windows 版開始使用

1. 將 zip 解壓縮到 `Documents`，不要直接在壓縮檔內開啟。
2. 打開 Codex App for Windows。
3. 按 `Ctrl + O` 或選擇 Add project，選擇這個資料夾。
4. 貼上：

```text
我是第一次使用 Jarvis，請用 $new-user-onboarding 帶我完成設定，並幫我建立第一個任務。
```

若你熟悉 PowerShell，可執行：

```powershell
py scripts/starter_health_check.py
```
