# /system_health

Check whether core folders exist, required starter files are present, and no private data has been added to public templates.
