# /project_intake

Use `$project-intake` to turn a vague idea into a concrete next step.
