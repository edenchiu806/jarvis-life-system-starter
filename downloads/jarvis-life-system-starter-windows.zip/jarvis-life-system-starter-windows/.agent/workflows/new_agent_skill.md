# /new_agent_skill

Use `$agent-skill-builder` to help the user design a new Agent, Skill, or workflow.
