# /daily_review

Use `$daily-review` and update memory only with the user's consent.
