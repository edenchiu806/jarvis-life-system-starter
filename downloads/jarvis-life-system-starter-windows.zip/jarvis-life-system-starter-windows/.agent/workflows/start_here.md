# /start_here

Use `$new-user-onboarding` to orient the user, create the first task, and explain the folder structure.
