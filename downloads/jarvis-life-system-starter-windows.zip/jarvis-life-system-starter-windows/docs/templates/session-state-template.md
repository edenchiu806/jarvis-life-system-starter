---
id: "{{task-id}}"
status: "active"
priority: "P2"
owner: "user"
last_updated: "{{date}}"
goal: "{{one-sentence-goal}}"
---

# {{task-title}}

## Current State

- 目前進度：
- 已完成：
- 卡住的地方：

## Decisions

- [{{date}}] 決定：

## Next Actions

- [ ] 下一步：

## Handoff Prompt

```text
請讀這份 session-state，從 Current State 和 Next Actions 接續。
```
