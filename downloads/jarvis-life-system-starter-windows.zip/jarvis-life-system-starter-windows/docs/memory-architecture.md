# 記憶架構

Jarvis 的記憶不是把所有聊天都塞進一個檔案，而是分層保存。

## 核心路徑

| 路徑 | 用途 |
|---|---|
| `vault/_memory/active-threads.json` | 目前有哪些活躍任務 |
| `vault/_memory/session-state/` | 每個任務的真相來源 |
| `vault/_memory/handoffs/` | 暫停或長對話後的恢復摘要 |
| `vault/_memory/context-window.json` | 全域焦點與近期提醒 |
| `vault/_memory/user/` | 使用者明確同意保存的偏好 |

## 使用原則

- 新任務先建立 `session-state`。
- 任務暫停前建立或更新 `handoff`。
- 可跨任務重用的方法，才放進 Skill 或 `docs/`。
- 私人資料只保留必要摘要，不複製原文。
