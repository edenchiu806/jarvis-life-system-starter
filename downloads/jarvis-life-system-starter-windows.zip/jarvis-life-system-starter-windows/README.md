# Jarvis Life System Starter

這是一份公開、乾淨、可改造的 Jarvis 人生系統入門包。

它保留多數人都用得到的骨架：

- `AGENTS.md`：讓 Codex 一打開專案就知道怎麼協作。
- `.agents/skills/`：Codex 原生可掃描的 Skill。
- `system/agents/`：Jarvis 角色分工。
- `.agent/workflows/`：可複製成 slash command 或固定流程的工作流。
- `vault/_memory/`：空白記憶與 handoff 骨架。
- `docs/`：記憶架構、協作模式、Harness 規範與新手教學。

這個包刻意不包含任何人的私人知識、商業資料、行程、客戶名單、
對話紀錄或既有 vault 內容。請把它當成自己的起始工作區。

## 第一次使用

1. 解壓縮這個資料夾。
2. 打開 Codex App。
3. 選擇這個資料夾作為專案。
4. 在 Codex 裡貼上：

```text
我是第一次使用 Jarvis，請用 $new-user-onboarding 帶我完成設定，並幫我建立第一個任務。
```

如果你想建立自己的 Agent 或 Skill，貼上：

```text
請用 $agent-skill-builder 幫我設計一個新的 Agent 或 Skill。
```

## 建議先讀

- `docs/new-user-guide.md`
- `docs/memory-architecture.md`
- `docs/collaboration-mode.md`
- `docs/harness-spec.md`
