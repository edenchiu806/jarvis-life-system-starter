# Windows

Windows 版：請先完整解壓縮，再用 Codex App 選擇資料夾。

```text
嗨 Jarvis，請帶我完成第一次設定，順便讓我體驗你可以怎麼幫我。
```
