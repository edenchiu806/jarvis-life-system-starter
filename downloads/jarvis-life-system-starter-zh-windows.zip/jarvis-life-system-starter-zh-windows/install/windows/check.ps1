Set-Location (Join-Path $PSScriptRoot "..\..")
py scripts/starter_health_check.py
Read-Host "按 Enter 關閉..."
