# Mac 版開始使用

1. 將資料夾解壓縮到 `Documents` 或你容易找到的位置。
2. 打開 Codex App。
3. 按 `Cmd + O`，選擇這個資料夾。
4. 貼上：

```text
我是第一次使用 Jarvis，請用 $new-user-onboarding 帶我完成設定，並幫我建立第一個任務。
```

若你熟悉 Terminal，可執行：

```bash
python3 scripts/starter_health_check.py
```
