# Windows

Bản Windows: hãy giải nén hoàn toàn trước, sau đó chọn thư mục trong Codex App.

```text
Chào Jarvis, hãy dẫn tôi hoàn tất thiết lập lần đầu và cho tôi trải nghiệm bạn có thể giúp tôi như thế nào.
```
