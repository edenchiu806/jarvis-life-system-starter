Set-Location (Join-Path $PSScriptRoot "..\..")
py scripts/starter_health_check.py
Read-Host "Nhấn Enter để đóng..."
