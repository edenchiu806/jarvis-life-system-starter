# Ghi nhớ người dùng

Chỉ lưu sở thích và bản tóm tắt khi người dùng đã đồng ý.
