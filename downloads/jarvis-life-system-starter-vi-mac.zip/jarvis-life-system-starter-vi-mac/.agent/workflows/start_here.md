# /start_here

Kích hoạt onboarding, hoàn tất thiết lập và đưa người dùng vào nhiệm vụ trải nghiệm hệ thống.
