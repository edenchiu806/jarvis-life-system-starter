# /web_research

Dùng web-research để tìm kiếm và tổng hợp dữ liệu mới.
