# /daily_review

Tổng kết tiến độ, điểm kẹt, bước đầu ngày mai và năng lực có thể đóng gói.
