# /project_intake

Biến ý tưởng mơ hồ thành dự án cụ thể và bước đầu tiên.
