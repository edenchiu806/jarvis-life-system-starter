# /system_health

Kiểm tra thư mục lõi, Skill, Agent, khung ghi nhớ và tệp tải xuống.
