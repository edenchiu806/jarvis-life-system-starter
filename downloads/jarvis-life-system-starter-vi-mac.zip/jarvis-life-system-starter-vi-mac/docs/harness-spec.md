# Quy tắc Harness

## Task Start Gate

- Mục tiêu là gì?
- Tiêu chí hoàn thành là gì?
- Có cần dữ liệu mới hoặc trình duyệt không?
- Có rủi ro riêng tư, tiền bạc, tài khoản hoặc công khai không?

## Proof Contract

Trước khi kết thúc, cung cấp ít nhất một bằng chứng: đường dẫn tệp, kết quả kiểm tra, liên kết nguồn, xác minh trang hoặc handoff.
