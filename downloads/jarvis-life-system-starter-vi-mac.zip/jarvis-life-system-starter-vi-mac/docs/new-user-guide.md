# Hướng dẫn cho người mới

Khi dùng lần đầu, bạn không cần nhập câu lệnh giống lập trình. Chỉ cần nói tự nhiên:

```text
Chào Jarvis, hãy dẫn tôi hoàn tất thiết lập lần đầu và cho tôi trải nghiệm bạn có thể giúp tôi như thế nào.
```

Onboarding của Jarvis gồm năm phần:

1. Cho bạn trải nghiệm nhanh: sắp xếp ý tưởng, tìm kiếm web, mở trang web và tạo ghi nhớ.
2. Trò chuyện để hiểu vai trò, mục tiêu, cách làm việc, công cụ thường dùng và ranh giới riêng tư của bạn.
3. Tạo bản đồ nhu cầu cá nhân đầu tiên.
4. Đề xuất Agent, Skill và Workflow phù hợp với bạn.
5. Tự tạo các tệp khởi đầu và nhiệm vụ tiếp theo trong phạm vi an toàn.
