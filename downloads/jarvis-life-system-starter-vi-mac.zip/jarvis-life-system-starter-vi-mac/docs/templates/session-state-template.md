---
id: "{{task-id}}"
status: "active"
priority: "P2"
last_updated: "{{date}}"
goal: "{{one-sentence-goal}}"
---

# {{task-title}}

## Trạng thái hiện tại

## Quyết định đã đưa ra

## Bước tiếp theo

## Câu nhắc để tiếp tục
