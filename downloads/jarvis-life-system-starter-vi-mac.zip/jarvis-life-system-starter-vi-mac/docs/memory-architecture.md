# Kiến trúc ghi nhớ

| Đường dẫn | Mục đích |
|---|---|
| `vault/_memory/active-threads.json` | Chỉ mục nhiệm vụ đang chạy |
| `vault/_memory/session-state/` | Nguồn sự thật cho nhiệm vụ có thể tiếp tục |
| `vault/_memory/handoffs/` | Ghi chú khởi động lại đã nén gọn |
| `vault/_memory/context-window.json` | Bảng điều khiển trọng tâm tổng quát |
| `vault/_memory/user/` | Sở thích người dùng đã được đồng ý lưu |
