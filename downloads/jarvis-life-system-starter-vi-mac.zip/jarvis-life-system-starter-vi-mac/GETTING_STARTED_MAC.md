# Mac

Bản Mac: giải nén rồi dùng Cmd + O trong Codex App để chọn thư mục.

```text
Chào Jarvis, hãy dẫn tôi hoàn tất thiết lập lần đầu và cho tôi trải nghiệm bạn có thể giúp tôi như thế nào.
```
