# Chỉ mục Starter Skills

- new-user-onboarding: hướng dẫn nhập môn và thiết lập cá nhân hóa
- web-research: tìm kiếm web và tổng hợp nguồn
- browser-operator: mở, kiểm tra và xác minh bằng trình duyệt
- agent-skill-builder: tạo Agent, Skill và Workflow
- memory-capture: ghi nhớ nhiệm vụ và handoff
- project-intake: tiếp nhận dự án mới
- daily-review: tổng kết và khép phiên mỗi ngày
