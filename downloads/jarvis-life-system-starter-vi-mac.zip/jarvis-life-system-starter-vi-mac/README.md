# Bộ khởi động Hệ thống cuộc sống Jarvis

Đây là bộ khởi động Jarvis công khai, sạch và có thể tùy biến. Bộ này được thiết kế cho người Việt Nam, có hướng dẫn nhập môn, tìm kiếm web, thao tác trình duyệt, ghi nhớ công việc và tự tạo Agent / Skill / Workflow.

## Lần đầu khởi động

```text
Chào Jarvis, hãy dẫn tôi hoàn tất thiết lập lần đầu và cho tôi trải nghiệm bạn có thể giúp tôi như thế nào.
```

## Năng lực có sẵn

- Hướng dẫn nhập môn: dẫn người dùng từng bước trải nghiệm năng lực, tạo bản đồ nhu cầu và xin đồng ý khi cần lưu thông tin.
- Tìm kiếm web: khi môi trường Codex hỗ trợ, tìm dữ liệu mới, tài liệu chính thức và nguồn bên ngoài.
- Thao tác trình duyệt: khi có công cụ trình duyệt, mở trang, kiểm tra giao diện, xác minh tải xuống hoặc biểu mẫu.
- Ghi nhớ công việc: lưu trạng thái nhiệm vụ, handoff, quyết định và bước tiếp theo.
- Tạo Agent / Skill: biến việc lặp lại thành Agent, Skill hoặc Workflow riêng.

## Riêng tư

Không chứa vault riêng tư, dữ liệu khách hàng, chiến lược kinh doanh, API key, token hoặc cấu hình máy cá nhân.
