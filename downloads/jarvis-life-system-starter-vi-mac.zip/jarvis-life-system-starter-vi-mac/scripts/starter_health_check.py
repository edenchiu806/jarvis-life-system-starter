#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
required = [
    "AGENTS.md",
    "CODEX.md",
    "docs/new-user-guide.md",
    "docs/capabilities.md",
    "docs/harness-spec.md",
    ".agents/skills/new-user-onboarding/SKILL.md",
    ".agents/skills/web-research/SKILL.md",
    ".agents/skills/browser-operator/SKILL.md",
    ".agents/skills/agent-skill-builder/SKILL.md",
    "vault/_memory/active-threads.json",
    "vault/_memory/context-window.json",
]
missing = [item for item in required if not (root / item).exists()]
if missing:
    print('Thiếu tệp:')
    for item in missing:
        print(f"- {item}")
    raise SystemExit(1)
print('Kiểm tra bộ khởi động Jarvis đã đạt.')
