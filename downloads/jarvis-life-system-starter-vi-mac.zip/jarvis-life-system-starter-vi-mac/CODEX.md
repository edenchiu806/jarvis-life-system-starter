# Ghi chú thiết lập Codex

Mở thư mục này trong Codex App và dùng Local mode để Codex có thể đọc và ghi trong không gian làm việc.

## Câu đầu tiên

```text
Chào Jarvis, hãy dẫn tôi hoàn tất thiết lập lần đầu và cho tôi trải nghiệm bạn có thể giúp tôi như thế nào.
```

Codex sẽ quét `.agents/skills`. Starter này có sẵn:

- `$new-user-onboarding`
- `$web-research`
- `$browser-operator`
- `$agent-skill-builder`
- `$memory-capture`
- `$project-intake`
- `$daily-review`

Nếu Skill chưa xuất hiện, hãy khởi động lại Codex hoặc mở lại thư mục.
