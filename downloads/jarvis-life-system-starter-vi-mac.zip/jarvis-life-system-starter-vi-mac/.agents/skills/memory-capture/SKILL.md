---
name: memory-capture
description: Lưu trạng thái nhiệm vụ, sở thích cá nhân, quyết định, bước tiếp theo và handoff để Jarvis có thể tiếp tục lần sau. Dùng khi người dùng muốn ghi nhớ, lưu tiến độ, tiếp tục lần sau, kết thúc phiên làm việc hoặc tạo bộ nhớ.
---

# Memory Capture

Trước khi lưu, xác định thông tin thuộc `session-state`, `handoff` hay sở thích `user`. Dữ liệu riêng tư chỉ lưu phần tóm tắt và trường cần thiết sau khi người dùng đồng ý.
