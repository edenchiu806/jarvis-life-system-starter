---
name: browser-operator
description: Dùng trình duyệt, in-app browser hoặc computer use nếu có để mở website, kiểm tra trang, xác minh tải xuống, đọc giao diện, bấm qua luồng hoặc thử biểu mẫu. Dùng khi nhiệm vụ cần open browser / inspect page / thao tác web / screenshot / xác minh trang.
---

# Browser Operator

1. Nói rõ sẽ mở trang nào và cần xác minh điều gì.
2. Dùng công cụ trình duyệt có sẵn để mở trang.
3. Kiểm tra chữ chính, nút bấm, liên kết tải xuống, khả năng đọc trên điện thoại và trạng thái lỗi.
4. Không nhập dữ liệu nhạy cảm trừ khi người dùng yêu cầu rõ và rủi ro đã được giải thích.
5. Nếu không có công cụ trình duyệt, đưa checklist kiểm tra thủ công.
