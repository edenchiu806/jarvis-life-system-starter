---
name: project-intake
description: Biến ý tưởng mơ hồ thành dự án có thể thực hiện, gồm mục tiêu, giới hạn, cột mốc đầu tiên, rủi ro, Agent/Skill/Workflow cần dùng và bước tiếp theo. Dùng khi người dùng có ý tưởng mới, dự án mới hoặc nhiệm vụ còn lộn xộn.
---

# Project Intake

1. Diễn đạt lại mục tiêu bằng một câu.
2. Xác định kết quả đầu tiên có thể nhìn thấy.
3. Liệt kê giới hạn, điều chưa biết và rủi ro.
4. Đề xuất Agent, Skill và Workflow cần dùng.
5. Tạo session-state đầu tiên.
