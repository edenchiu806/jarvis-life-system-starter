---
name: web-research
description: Dùng năng lực tìm kiếm web nếu có để thu thập thông tin mới nhất, tài liệu chính thức, thông tin sản phẩm, giá cả, quy định, tin tức hoặc nguồn bên ngoài, rồi tóm tắt có nguồn. Dùng khi nhiệm vụ cần current / latest / web / research / tìm kiếm / xác minh.
---

# Web Research

1. Xác định có thật sự cần dữ liệu bên ngoài mới nhất không.
2. Ưu tiên nguồn chính thức, tài liệu gốc, trang sản phẩm, trang quy định hoặc nguồn đáng tin cậy.
3. Khi tóm tắt, giữ liên kết nguồn và ngày tháng.
4. Không xem kết quả tìm kiếm là chân lý tuyệt đối; đánh dấu phần chưa chắc chắn.
5. Nếu môi trường Codex hiện tại không có web search, nói rõ giới hạn và đưa từ khóa để người dùng tự kiểm tra.
