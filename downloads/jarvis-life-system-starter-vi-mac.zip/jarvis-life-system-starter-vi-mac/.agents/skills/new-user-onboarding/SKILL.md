---
name: new-user-onboarding
description: Dẫn người dùng mới lần đầu sử dụng Jarvis bằng cuộc trò chuyện tự nhiên, giúp họ trải nghiệm năng lực AI System, từng bước hiểu hồ sơ cá nhân và nhu cầu, rồi tự lập kế hoạch và tạo Agent, Skill, Workflow phù hợp. Dùng khi người dùng mới bắt đầu, muốn thiết lập, muốn trải nghiệm hệ thống AI hoặc cần onboarding.
---

# New User Onboarding

## Quy trình

1. Bắt đầu bằng lời chào tự nhiên, không yêu cầu người dùng nhập câu lệnh giống lập trình.
2. Mời người dùng chọn một việc nhỏ họ muốn được giúp hôm nay, rồi biểu diễn ngay: sắp xếp ý tưởng, tìm kiếm hoặc tạo nhiệm vụ.
3. Hỏi từng bước: cách xưng hô, vai trò, mục tiêu chính, điểm thường bị kẹt, công cụ đang dùng, cách muốn cộng tác với AI, dữ liệu không được lưu.
4. Tạo "bản đồ nhu cầu cá nhân": mục tiêu, loại nhiệm vụ, Agent đề xuất, Skill đề xuất, Workflow đề xuất.
5. Tự tạo các starter files an toàn: session-state, bản nháp Skill, bản nháp Agent hoặc bản nháp workflow.
6. Kết thúc bằng câu người dùng có thể nói lần sau để tiếp tục.

## Trải nghiệm mẫu

- Nếu cần dữ liệu mới, dùng `$web-research`.
- Nếu cần kiểm tra trang web, dùng `$browser-operator`.
- Nếu người dùng có việc lặp lại, dùng `$agent-skill-builder` để tạo bản đầu tiên.

## Riêng tư

Trước khi lưu thông tin cá nhân, hãy giải thích mục đích và xin đồng ý. Không yêu cầu mật khẩu, khóa API, giấy tờ tùy thân, dữ liệu ngân hàng hoặc nguyên văn tin nhắn riêng tư.
