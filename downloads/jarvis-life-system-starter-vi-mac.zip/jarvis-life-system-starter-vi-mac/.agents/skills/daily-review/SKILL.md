---
name: daily-review
description: Tổng kết cuối ngày: tiến độ, điểm kẹt, quyết định, bước đầu tiên ngày mai và mẫu lặp lại có thể biến thành Skill hoặc Workflow. Dùng khi người dùng muốn tổng kết hôm nay, kết thúc phiên làm việc hoặc chuẩn bị cho ngày mai.
---

# Daily Review

Hỏi năm điều: hôm nay tiến triển gì, kẹt ở đâu, quyết định nào đã được đưa ra, bước đầu tiên ngày mai là gì, có mẫu lặp lại nào đáng biến thành Skill không.
