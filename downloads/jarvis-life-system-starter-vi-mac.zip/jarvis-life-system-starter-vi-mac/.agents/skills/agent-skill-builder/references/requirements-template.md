# Bản nháp yêu cầu

## Tên
## Vấn đề cần giải quyết
## Ví dụ kích hoạt
## Không nên kích hoạt khi
## Đầu vào cần có
## Đầu ra mong muốn
## Cách xác minh
