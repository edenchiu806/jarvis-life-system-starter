---
name: agent-skill-builder
description: Biến việc lặp lại, nhu cầu vai trò, phương pháp làm việc hoặc ý tưởng Skool/Skill của người dùng thành Jarvis Agent, Codex Skill hoặc Workflow. Dùng khi người dùng muốn tạo Agent, Skill, workflow, vai trò trợ lý, mẫu nhiệm vụ hoặc năng lực tự động hóa.
---

# Agent / Skill Builder

1. Làm rõ năng lực này giải quyết vấn đề lặp lại nào.
2. Quyết định nên tạo Agent, Skill hay Workflow.
3. Dùng `references/requirements-template.md` để tạo yêu cầu.
4. Khi cần, tạo `system/agents/*.yaml`, `.agents/skills/*/SKILL.md` hoặc `.agent/workflows/*.md`.
5. Sau khi tạo, kiểm thử bằng một tình huống thật.

Nếu người dùng nói Skool, hãy làm rõ họ đang nói Codex Skill hay nền tảng cộng đồng Skool.
